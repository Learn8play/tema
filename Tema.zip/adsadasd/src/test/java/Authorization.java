import io.restassured.response.Response;
import org.apache.commons.lang3.RandomStringUtils;
import static io.restassured.RestAssured.given;



// this class will perform the Authorization generating a token that can be used later on with API calls

public class Authorization {

    public String token ;
    public int authorizationId;
    public Response authorizationsResponse ;
    //private static Authorization singleton = new Authorization();


    // this method will create a new authorization and obtain the token value needed for subsequent requests


    public Authorization(){
        createNewGitAuthorization();
    }


/*
    public static Authorization obtainAuthObject(){
        return singleton;
    }
    */

    public static void main(String[] args) {
        Authorization obj = new Authorization();
        System.out.println(obj.token);
        obj.revokeAuthorization();


    }

    //his method will create an authorization and save the token
    public void createNewGitAuthorization(){

        String s = ConfigInfo.getBase64AuthToken() ;

        authorizationsResponse = given().log().all().header("Authorization", "Basic "+ ConfigInfo.getBase64AuthToken()).body("{\n" +
                "  \"scopes\": [\n" +
                "    \"public_repo\"\n" +
                "  , \"delete_repo\"],\n" +
                "  \"note\": \"test"+RandomStringUtils.randomAlphanumeric(5).toUpperCase()+"\"\n" +
                "}").when().log().all().request("POST",
                "/authorizations");
        System.out.println(authorizationsResponse.asString());
        token = authorizationsResponse.path("token");
        authorizationId = authorizationsResponse.path("id");
        assert token != null;

    }

    // this method will delete the authorization
    public  void revokeAuthorization(){

        given().log().all().header("Authorization", "Basic "+ConfigInfo.getBase64AuthToken()).when().log().all().request("DELETE",
                "/authorizations/"+authorizationId).then().assertThat().statusCode(204);

    }

    public  String getToken(){
        return token ;
    }

}

