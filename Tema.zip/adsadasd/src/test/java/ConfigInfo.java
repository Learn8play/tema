import io.restassured.RestAssured;

import java.util.Base64;


// this class will hold all the known configurable values at the start of testing

public class ConfigInfo {

    private static String user = "learn8play";
    private static String password = "njitfc0";


    private static String base64Auth;


    static {
        RestAssured.baseURI = "https://api.github.com" ;

        //obtain base64 user:password for Authorization header
        byte[] encodedUserPassword = Base64.getEncoder().encode((user+":"+password).getBytes());
        base64Auth = new String(encodedUserPassword) ;
        //System.out.println("Value: " + new String(encodedUserPassword));
    }

    public static String getBase64AuthToken() {
        return base64Auth ;

    }

    public static String getUser(){
        return user ;
    }

}
