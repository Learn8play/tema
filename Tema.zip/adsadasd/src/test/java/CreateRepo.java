import io.restassured.response.Response;
import org.apache.commons.lang3.RandomStringUtils;

import java.util.ArrayList;
import java.util.List;

import static io.restassured.RestAssured.given;



// this class holds the functionality of creating a repository and will return a io.restassured.response.Response object resulted from triggering the create repo API
public class CreateRepo {

    private static Authorization autorizationInstance  = new Authorization();
    private List<String> repoNames= new ArrayList<>();
    private Response[] responses = new Response[3]  ; //can be changed to arrayList to support variable size

    public static Authorization getAutorizationInstance(){
        return autorizationInstance ;
    }

    public static void main(String[] args) {
        CreateRepo x = new CreateRepo();
        for (int i =0 ; i<3 ;i++){
            System.out.println(x.produceRepo().asString());
            System.out.println(x.getRepoNames().get(i));
        }


    }

    public Response produceRepo(){
        //String x = autorizationInstance.getToken() ;
        //System.out.println(ConfigInfo.base64Auth);

        Response a = given().log().all().header("Authorization", "token "+ autorizationInstance.getToken()).body("{\n" +
                "  \"name\": \"Repo-"+ generateName()+ "\",\n" +
                "  \"description\": \"This is one of my repositories\"\n" +
                "}").when().log().all().request("POST",
                "/user/repos");
        //System.out.println(a.asString());
        //responses[0].then().statusCode(201);
        return a ;

    }

    public List<String> getRepoNames(){
        return repoNames ;
    }

    private  String generateName(){
        String s = RandomStringUtils.randomAlphanumeric(5).toUpperCase();
        repoNames.add(s);

        return s ;
    }

    //return the list of repoes created with a single object of this class
    public Response[] getListOfRepos(){
        return responses ;
    }


}
