import io.restassured.response.Response;

import static io.restassured.RestAssured.given;



// this class holds the functionality of deleting a repository and will return a io.restassured.response.Response object resulted from triggering the delete repo API
public class DeleteARepo {



    public  Authorization autorizationInstance  = new Authorization();

    /*public static void main(String[] args) {
        CreateRepo x = new CreateRepo();
        System.out.println(x.produceRepo().asString());
    }*/

    // this method will take as args the name of the repo and the name of the user to perform the git repo deletion and will return a io.restassured.response.Response object
    public Response deleteRepo(String owner , String repo){
        String x = autorizationInstance.getToken() ;
        //System.out.println(ConfigInfo.base64Auth);

        Response a = given().log().all().header("Authorization", "token "+ autorizationInstance.getToken()).when().log().all().request("DELETE",
                "/repos/"+owner+"/"+repo);
        //System.out.println(a.asString());
        //responses[0].then().statusCode(201);
        return a ;

    }


}


