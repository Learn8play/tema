import io.restassured.response.Response;

import static io.restassured.RestAssured.given;


public class ListUserRepos {
    static Authorization autorizationInstance  = new Authorization();
    //Response listOfUserRepos  ;


    // this method will generate a get repositories call for the current user and will return a io.restassured.response.Response object
    public Response listUserRepos(){

        Response a = given().log().all().header("Authorization", "token "+ autorizationInstance.getToken()).when().log().all().request("GET",
                "/user/repos");
        System.out.println(a.asString());
        //responses[0].then().statusCode(201);
        return a ;

    }


    public static void main(String[] args) {
        ListUserRepos a = new ListUserRepos();
        a.listUserRepos();
    }
}
