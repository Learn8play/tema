import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.junit.AfterClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import org.junit.After;

import java.util.ArrayList;
import java.util.List;


@RunWith(Parameterized.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestAll {

    static Authorization autorizationInstance = new Authorization();
    static CreateRepo obj = new CreateRepo();
    static Response[] responses = new Response[3];
    static List<String> repoNames;


    @Parameterized.Parameters
    public static Object[][] data() {
        return new Object[2][0];
    }





    @AfterClass

    public static void deleteReposAndRevokeAuthorization() {

        JsonPath allRepos = new ListUserRepos().listUserRepos().jsonPath();
        List<String> all = allRepos.get("name");
        System.out.println("XXXX");
        System.out.println("" + allRepos.get("name"));


        DeleteARepo obj = new DeleteARepo();
        for (String n : all) {

            //String repoName = responses[i].path("name");
            obj.deleteRepo(ConfigInfo.getUser(), n).then().statusCode(204);
        }

        // to investigate why 2 repos are created after delete


        autorizationInstance.revokeAuthorization();

    }

    @Test
    public void A_createRepos() {
        for (int i = 0; i < 3; i++) {
            responses[i] = obj.produceRepo();
            responses[i].then().statusCode(201);
        }
    }


    @Test
    public void B_deleteRepo() {
        DeleteARepo obj = new DeleteARepo();
        String repoName = responses[0].path("name");
        obj.deleteRepo(ConfigInfo.getUser(), repoName).then().statusCode(204);
    }

    @Test
    public void C_tryDeleteRepo() {
        DeleteARepo obj = new DeleteARepo();
        String repoName = responses[0].path("name");
        obj.deleteRepo(ConfigInfo.getUser(), repoName).then().statusCode(404);

    }

    @Test
    public void D_listRepos() {
        ListUserRepos obj = new ListUserRepos();
        JsonPath allRepos = obj.listUserRepos().jsonPath();

        repoNames = allRepos.get("name");
        //System.out.println("" + allRepos.get("name"));
        List<String> createdRepos = new ArrayList<>();
        for (Response r : responses) {
            createdRepos.add(r.path("name"));
        }
        assertThat("One or more created repos are not found in the Get repositories responses",
        createdRepos, containsInAnyOrder(repoNames));

    }

}
