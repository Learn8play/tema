import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;


@RunWith(Parameterized.class)
public class TestListRepo {

    static Authorization autorizationInstance = new Authorization();
    static CreateRepo obj = new CreateRepo();
    static Response[] responses = new Response[3]  ;
    static List<String> repoNames;

    @Parameterized.Parameters
    public static Object[][] data() {
        return new Object[2][0];
    }

    @AfterClass

    public static void revokeAuthorization(){

        autorizationInstance.revokeAuthorization();

    }

    @Before

    public void setup (){

        for(int i=0 ;i < 3 ; i++){
            responses[i]=obj.produceRepo();
            responses[i].then().statusCode(201);
        }

        DeleteARepo obj= new DeleteARepo();
        String repoName = responses[0].path("name");
        obj.deleteRepo(ConfigInfo.getUser(),repoName).then().statusCode(204);

    }

    @After

    public void cleanup(){
        DeleteARepo obj= new DeleteARepo();
        for(String n : repoNames){

            //String repoName = responses[i].path("name");
            obj.deleteRepo(ConfigInfo.getUser(),n ).then().statusCode(204);
        }


    }

    @Test
    public void listRepos(){
        ListUserRepos obj = new ListUserRepos();
        JsonPath allRepos = obj.listUserRepos().jsonPath();

        repoNames = allRepos.get("name");
        //System.out.println("" + allRepos.get("name"));
        List<String> createdRepos = new ArrayList<>();
        for (Response r : responses) {
            createdRepos.add(r.path("name"));
        }
        assertThat("One or more created repos are not found in the Get repositories responses",
                createdRepos, containsInAnyOrder(repoNames));
    }


}
