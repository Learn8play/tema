import io.restassured.response.Response;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;


@RunWith(Parameterized.class)
public class TestRepoDeletionOnAlreadyDeletedRepo {
    static Authorization autorizationInstance = new Authorization();
    static CreateRepo obj = new CreateRepo();
    static Response[] responses = new Response[3]  ;



    @Parameterized.Parameters
    public static Object[][] data() {
        return new Object[2][0];
    }

    @AfterClass

    public static void revokeAuthorization(){

        autorizationInstance.revokeAuthorization();

    }

    @Before

    public void createThreeRepos (){

        for(int i=0 ;i < 3 ; i++){
            responses[i]=obj.produceRepo();
            responses[i].then().statusCode(201);
        }
    }

    @After

    public void removeCreatedRepos(){
        DeleteARepo obj= new DeleteARepo();
        for(int i= 0 ;i<responses.length ;i++){

            //remember to refactor to use an ArrayList
            if (i == 0 ){
                continue;
            }
            String repoName = responses[i].path("name");
            obj.deleteRepo(ConfigInfo.getUser(),repoName).then().statusCode(204);
        }
    }

    @Test
    public void deleteUnexistingRepo(){
        DeleteARepo obj= new DeleteARepo();
        String repoName = responses[0].path("name");
        obj.deleteRepo(ConfigInfo.getUser(),repoName).then().statusCode(204);
        //System.out.println(obj.deleteRepo(ConfigInfo.getUser(),repoName).asString());
        obj.deleteRepo(ConfigInfo.getUser(),repoName).then().statusCode(404);

    }
}

